# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: block-tags.spec.js >> PlusMagi Markdown — Block Editor >> ignores empty tokens from consecutive comma separators
- Location: tests/block-tags.spec.js:213:2

# Error details

```
TimeoutError: locator.press: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('input[placeholder="Add new tag"]')

```

```
Error: page.waitForResponse: Test ended.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - text:           
    - generic:
      - main:
        - generic:
          - generic:
            - heading "Add Post" [level=1] [ref=e3]
            - generic [ref=e6]:
              - region "Editor top bar" [ref=e7]:
                - generic [ref=e8]:
                  - generic [ref=e12]:
                    - link "ดูเรื่อง" [ref=e13] [cursor=pointer]:
                      - /url: edit.php?post_type=post
                      - img [ref=e17]
                    - generic:
                      - img
                  - toolbar "เครื่องมือเอกสาร" [ref=e20]:
                    - generic [ref=e21]:
                      - button "Block Inserter" [ref=e22] [cursor=pointer]:
                        - img [ref=e23]
                      - button "ย้อนกลับ" [disabled] [ref=e25] [cursor=pointer]:
                        - img [ref=e26]
                      - button "กลับไปทำใหม่" [disabled] [ref=e28] [cursor=pointer]:
                        - img [ref=e29]
                      - button "Document Overview" [ref=e31] [cursor=pointer]:
                        - img [ref=e32]
                  - button "No title · เรื่อง ⌘K" [ref=e36] [cursor=pointer]:
                    - heading "No title · เรื่อง" [level=1] [ref=e38]:
                      - generic [ref=e39]: No title
                      - generic [ref=e40]: · เรื่อง
                    - generic [ref=e41]: ⌘K
                  - generic [ref=e42]:
                    - button "บันทึกฉบับร่าง" [disabled] [ref=e43] [cursor=pointer]
                    - button "View" [ref=e45] [cursor=pointer]:
                      - img [ref=e46]
                    - button "Settings" [expanded] [pressed] [ref=e49] [cursor=pointer]:
                      - img [ref=e50]
                    - button "เผยแพร่" [disabled] [ref=e52] [cursor=pointer]
                    - button "ตัวเลือก" [ref=e54] [cursor=pointer]:
                      - img [ref=e55]
              - generic [ref=e57]:
                - region "Editor content" [ref=e58]:
                  - iframe [ref=e64]:
                    - generic [active] [ref=f1e1]:
                      - textbox "ใส่ชื่อ" [ref=f1e3]:
                        - generic: ใส่ชื่อ
                      - generic [ref=f1e6]:
                        - button "Add default block" [ref=f1e7]: พิมพ์ / เพื่อเลือกบล็อก
                        - button "เพิ่มบล็อก" [ref=f1e9] [cursor=pointer]:
                          - img
                - region "Editor settings" [ref=e65]:
                  - generic [ref=e67]:
                    - generic [ref=e68]:
                      - tablist [ref=e69]:
                        - tab "เรื่อง" [selected] [ref=e70] [cursor=pointer]:
                          - generic [ref=e71]: เรื่อง
                        - tab "บล็อก" [ref=e72] [cursor=pointer]:
                          - generic [ref=e73]: บล็อก
                      - button "Close Settings" [ref=e74] [cursor=pointer]:
                        - img [ref=e75]
                    - tabpanel "เรื่อง" [ref=e78]:
                      - generic [ref=e80]:
                        - generic [ref=e82]:
                          - img [ref=e83]
                          - heading "No title" [level=2] [ref=e85]:
                            - generic [ref=e86]: No title
                          - button "Actions" [ref=e87] [cursor=pointer]:
                            - img [ref=e88]
                        - generic [ref=e90]:
                          - generic [ref=e91]: Notice
                          - paragraph [ref=e93]: Selecting a featured image is recommended for an optimal user experience.
                        - button "กำหนดรูปประจำเรื่อง" [ref=e96] [cursor=pointer]
                        - button "Add an excerpt…" [ref=e99] [cursor=pointer]
                        - generic [ref=e101]: Last edited a second ที่ผ่านมา.
                        - generic [ref=e103]:
                          - generic [ref=e104]:
                            - generic [ref=e105]: สถานะ
                            - 'button "Change status: ฉบับร่าง" [ref=e108] [cursor=pointer]':
                              - img [ref=e109]
                              - text: ฉบับร่าง
                          - generic [ref=e111]:
                            - generic [ref=e112]: เผยแพร่
                            - 'button "Change date: โดยทันที" [ref=e115] [cursor=pointer]': โดยทันที
                          - generic [ref=e116]:
                            - generic [ref=e117]: Slug
                            - 'button "Change link: 14993" [ref=e120] [cursor=pointer]': "14993"
                          - generic [ref=e121]:
                            - generic [ref=e122]: ผู้เขียน
                            - 'button "Change author: phunsanit" [ref=e125] [cursor=pointer]': phunsanit
                          - generic [ref=e126]:
                            - generic [ref=e127]: การสนทนา
                            - button "Change discussion options" [ref=e130] [cursor=pointer]: Closed
                          - generic [ref=e131]:
                            - generic [ref=e132]: Format
                            - 'button "Change format: มาตรฐาน" [ref=e135] [cursor=pointer]': มาตรฐาน
                      - generic [ref=e136]:
                        - heading "PlusMagi Tags Reindex" [level=2] [ref=e137]:
                          - button "PlusMagi Tags Reindex" [expanded] [ref=e138] [cursor=pointer]:
                            - img [ref=e139]
                            - text: PlusMagi Tags Reindex
                        - generic [ref=e142]:
                          - generic [ref=e144]:
                            - generic [ref=e145]:
                              - checkbox "Enable Gap Filling (Reuse missing term_id)" [checked] [ref=e146] [cursor=pointer]
                              - img
                            - generic [ref=e147] [cursor=pointer]: Enable Gap Filling (Reuse missing term_id)
                          - paragraph [ref=e148]:
                            - generic [ref=e149]: When disabled, new tags use WordPress default auto-increment.
                        - generic [ref=e153]: Reindexing tags...
                      - heading "AMP" [level=2] [ref=e155]:
                        - button "AMP" [ref=e156] [cursor=pointer]:
                          - img [ref=e157]
                          - text: AMP
                      - generic [ref=e159]:
                        - heading "หมวดหมู่" [level=2] [ref=e160]:
                          - button "หมวดหมู่" [expanded] [ref=e161] [cursor=pointer]:
                            - img [ref=e162]
                            - text: หมวดหมู่
                        - group "หมวดหมู่" [ref=e168]
                - region "Editor publish":
                  - button "เปิดส่วนควบคุมการเผยแพร่" [ref=e170] [cursor=pointer]
  - paragraph [ref=e171]: การแจ้งเตือน
  - generic [ref=e172]: Selecting a featured image is recommended for an optimal user experience.
```

# Test source

```ts
  1   | // @ts-check
  2   | const { test, expect } = require('@playwright/test');
  3   | const { resolveAdminTestUrl } = require('./helpers/admin-url');
  4   | 
  5   | test.describe('PlusMagi Markdown — Block Editor', () => {
  6   | 
  7   | 	// Increase timeout to handle slow page loads.
  8   | 	test.setTimeout(600_000);
  9   | 
  10  | 	const ADMIN_TEST_URL = resolveAdminTestUrl('/wp-admin/post-new.php');
  11  | 
  12  | 	const addTagEndpointPattern = /\/wp-json\/plusmagi-tags\/v1\/add-tag/;
  13  | 
  14  | 	async function addTagsAndWait(page, tagInput, value, confirmKey = 'Enter') {
> 15  | 		const addTagResponsePromise = page.waitForResponse(
      |                                      ^ Error: page.waitForResponse: Test ended.
  16  | 			(response) => addTagEndpointPattern.test(response.url()) && response.request().method() === 'POST',
  17  | 			{ timeout: 30_000 }
  18  | 		);
  19  | 
  20  | 		await tagInput.fill(value);
  21  | 		if (confirmKey) {
  22  | 			await tagInput.press(confirmKey);
  23  | 		}
  24  | 
  25  | 		const addTagResponse = await addTagResponsePromise;
  26  | 		expect(addTagResponse.ok()).toBe(true);
  27  | 		await expect(tagInput).toHaveValue('');
  28  | 
  29  | 		return addTagResponse.json();
  30  | 	}
  31  | 
  32  | 	async function openPanelAndGetInput(page) {
  33  | 		const panelToggle = page.locator('button.components-panel__body-toggle').filter({ hasText: /PlusMagi Tags Reindex/i });
  34  | 		test.skip((await panelToggle.count()) === 0, 'Environment is not deployed with the PlusMagi editor panel yet.');
  35  | 		await expect(panelToggle).toBeVisible({ timeout: 30_000 });
  36  | 
  37  | 		const isExpanded = await panelToggle.getAttribute('aria-expanded');
  38  | 		if (isExpanded === 'false') {
  39  | 			await panelToggle.click();
  40  | 		}
  41  | 
  42  | 		const tagInput = page.locator('input[placeholder="Add new tag"]');
  43  | 		await expect(tagInput).toBeVisible();
  44  | 		return tagInput;
  45  | 	}
  46  | 
  47  | 	async function publishCurrentPost(page) {
  48  | 		const titleInput = page.locator('h1.editor-post-title__input').first();
  49  | 		if (await titleInput.isVisible({ timeout: 5000 }).catch(() => false)) {
  50  | 			const currentTitle = await titleInput.inputValue();
  51  | 			if (!currentTitle.trim()) {
  52  | 				await titleInput.fill(`Playwright Post ${Date.now()}`);
  53  | 			}
  54  | 		}
  55  | 
  56  | 		const publishToggle = page.locator('button.editor-post-publish-panel__toggle').first();
  57  | 		if (await publishToggle.isVisible({ timeout: 5000 }).catch(() => false)) {
  58  | 			if (await publishToggle.isEnabled()) {
  59  | 				await publishToggle.click();
  60  | 			}
  61  | 		}
  62  | 
  63  | 		const publishButton = page
  64  | 			.locator('button.editor-post-publish-button, button.editor-post-publish-button__button')
  65  | 			.filter({ hasText: /Publish/i })
  66  | 			.last();
  67  | 
  68  | 		test.skip(!(await publishButton.isVisible({ timeout: 10000 }).catch(() => false)), 'Publish button is unavailable in this editor state.');
  69  | 		await publishButton.click();
  70  | 
  71  | 		await page
  72  | 			.locator('.editor-post-publish-panel__postpublish-header, .components-snackbar-list')
  73  | 			.first()
  74  | 			.waitFor({ state: 'visible', timeout: 30_000 });
  75  | 	}
  76  | 
  77  | 	test.beforeEach(async ({ page }) => {
  78  | 		// Navigate to the new post editor page.
  79  | 		await page.goto(ADMIN_TEST_URL, { waitUntil: 'domcontentloaded', timeout: 600_000 });
  80  | 
  81  | 		// Skip fast if this environment user cannot access wp-admin content editing.
  82  | 		test.skip(
  83  | 			!(await page.locator('#wpadminbar').count()),
  84  | 			'Environment user cannot access wp-admin post editor.'
  85  | 		);
  86  | 
  87  | 		// Wait until the editor shell is fully visible.
  88  | 		await page.locator('.edit-post-layout').waitFor({ state: 'visible', timeout: 60_000 });
  89  | 		await page.waitForTimeout(2000); // Give Gutenberg React time to finish rendering the UI.
  90  | 
  91  | 		// Close the Gutenberg welcome popup if it appears.
  92  | 		const welcomeClose = page.locator('.components-modal__header button').first();
  93  | 		if (await welcomeClose.isVisible({ timeout: 5000 }).catch(() => false)) {
  94  | 			await welcomeClose.click();
  95  | 		}
  96  | 
  97  | 		// Click the "Post" tab in the sidebar so the plugin panel becomes visible.
  98  | 		const postTab = page.locator('button.edit-post-sidebar__panel-tab').first();
  99  | 		if (await postTab.isVisible()) {
  100 | 			await postTab.click();
  101 | 		}
  102 | 	});
  103 | 
  104 | 	test('plugin panel renders and supports enter/comma/multi-input tag additions', async ({ page }) => {
  105 | 		// Find the plugin panel by its registered title.
  106 | 		const panelToggle = page.locator('button.components-panel__body-toggle').filter({ hasText: /PlusMagi Tags Reindex/i });
  107 | 
  108 | 		test.skip((await panelToggle.count()) === 0, 'Environment is not deployed with the PlusMagi editor panel yet.');
  109 | 
  110 | 		await expect(panelToggle).toBeVisible({ timeout: 30_000 });
  111 | 
  112 | 		// If the panel is collapsed, expand it.
  113 | 		const isExpanded = await panelToggle.getAttribute('aria-expanded');
  114 | 		if (isExpanded === 'false') {
  115 | 			await panelToggle.click();
```